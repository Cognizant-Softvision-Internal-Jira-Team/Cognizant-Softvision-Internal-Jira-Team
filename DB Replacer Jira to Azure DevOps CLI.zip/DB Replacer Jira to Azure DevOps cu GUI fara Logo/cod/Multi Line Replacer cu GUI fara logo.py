import csv
import os
import tkinter as tk
from tkinter import filedialog

def replace_text(data_csv_path, list_csv_path, output_csv_path, case_sensitive=True):
    if not os.path.isfile(data_csv_path) or not os.path.isfile(list_csv_path):
        raise FileNotFoundError("Input file not found.")

    find_replace_dict = {}
    with open(list_csv_path, 'r', newline='') as list_csv:
        list_reader = csv.reader(list_csv)
        
        # Skip the header of the "list" CSV
        header_list = next(list_reader, None)
        if header_list is not None and len(header_list) == 2:
            for row in list_reader:
                find_replace_dict[row[0]] = row[1]

    # Function to perform case-sensitive or case-insensitive replacement
    def get_replacement(col):
        return find_replace_dict.get(col, col) if case_sensitive else find_replace_dict.get(col.lower(), col)

    with open(data_csv_path, 'r', newline='') as data_csv, \
            open(output_csv_path, 'w', newline='') as output_csv:
        data_reader = csv.reader(data_csv)
        output_writer = csv.writer(output_csv)

        header = next(data_reader, None)
        if header:
            output_writer.writerow(header)

        for row in data_reader:
            updated_row = [get_replacement(col) for col in row]
            output_writer.writerow(updated_row)

def browse_file(entry_var):
    file_path = filedialog.askopenfilename()
    entry_var.set(file_path)

def run_replacer(data_entry_var, list_entry_var, output_entry_var, case_sensitive_var):
    data_csv_path = data_entry_var.get()
    list_csv_path = list_entry_var.get()
    output_csv_path = output_entry_var.get()
    case_sensitive = case_sensitive_var.get()

    try:
        replace_text(data_csv_path, list_csv_path, output_csv_path, case_sensitive)
        result_label.config(text="Text replacement successful. Check the 'output.csv' file.", fg="green")
    except FileNotFoundError as e:
        result_label.config(text=f"Error: {e}", fg="red")
    except Exception as e:
        result_label.config(text=f"Error: {e}", fg="red")

# Create the main window
window = tk.Tk()
window.title("Multi Line Replacer")

# Create and set labels and entry widgets
tk.Label(window, text="Data CSV (fisierul in care vrei schimbarile):").grid(row=0, column=0, padx=10, pady=5)
data_entry_var = tk.StringVar()
data_entry = tk.Entry(window, textvariable=data_entry_var, width=40)
data_entry.grid(row=0, column=1, columnspan=2, pady=5)
tk.Button(window, text="Cauta!", command=lambda: browse_file(data_entry_var)).grid(row=0, column=3, padx=10)

tk.Label(window, text="Lista CSV pt find&replace (sa aibe capete de tabel!):").grid(row=1, column=0, padx=10, pady=5)
list_entry_var = tk.StringVar()
list_entry = tk.Entry(window, textvariable=list_entry_var, width=40)
list_entry.grid(row=1, column=1, columnspan=2, pady=5)
tk.Button(window, text="Cauta!", command=lambda: browse_file(list_entry_var)).grid(row=1, column=3, padx=10)

tk.Label(window, text="Output CSV (mai intai creeaza-l la locatia dorita printr-un .txt pe care apoi sa il redenumesti in .csv):").grid(row=2, column=0, padx=10, pady=5)
output_entry_var = tk.StringVar()
output_entry = tk.Entry(window, textvariable=output_entry_var, width=40)
output_entry.grid(row=2, column=1, columnspan=2, pady=5)
tk.Button(window, text="Cauta!", command=lambda: browse_file(output_entry_var)).grid(row=2, column=3, padx=10)

# Create and set the case-sensitive checkbox
case_sensitive_var = tk.BooleanVar()
case_sensitive_check = tk.Checkbutton(window, text="Case-sensitive (recomand cu caldura!)", variable=case_sensitive_var)
case_sensitive_check.grid(row=3, column=1, pady=5)

# Create and set the run button
tk.Button(window, text="Ruleaza!", command=lambda: run_replacer(data_entry_var, list_entry_var, output_entry_var, case_sensitive_var)).grid(row=3, column=2, pady=10)

# Create and set the result label
result_label = tk.Label(window, text="", fg="black")
result_label.grid(row=3, column=3, pady=10)

# Create and set the italic footer label
footer_label = tk.Label(window, text="Have no care with ©FilipWare - very nice software, not joke!", font=("italic", 8))
footer_label.grid(row=4, column=0, columnspan=4, sticky=tk.E, pady=(10, 0))

# Start the Tkinter event loop
window.mainloop()
