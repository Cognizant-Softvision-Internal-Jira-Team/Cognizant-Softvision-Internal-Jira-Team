import csv

def replace_text(data_csv_path, list_csv_path, output_csv_path, case_sensitive=True):
    # Read the "list" CSV and create a dictionary for mapping find and replace strings
    find_replace_dict = {}
    with open(list_csv_path, 'r', newline='') as list_csv:
        list_reader = csv.reader(list_csv)
        for row in list_reader:
            if len(row) == 2:
                find_replace_dict[row[0]] = row[1]

    # Function to perform case-sensitive or case-insensitive replacement
    def get_replacement(col):
        return find_replace_dict.get(col, col) if case_sensitive else find_replace_dict.get(col.lower(), col)

    # Open the "data" CSV for reading and create a new CSV for writing the updated data
    with open(data_csv_path, 'r', newline='') as data_csv, \
            open(output_csv_path, 'w', newline='') as output_csv:
        data_reader = csv.reader(data_csv)
        output_writer = csv.writer(output_csv)

        for row in data_reader:
            # Replace text in each column based on the find_replace_dict
            updated_row = [get_replacement(col) for col in row]
            output_writer.writerow(updated_row)

if __name__ == "__main__":
    # Replace 'data.csv', 'list.csv', and 'output.csv' with your file paths
    data_csv_path = 'data.csv'
    list_csv_path = 'list.csv'
    output_csv_path = 'output.csv'

    try:
        replace_text(data_csv_path, list_csv_path, output_csv_path, case_sensitive=True)
        print("Case-sensitive text replacement successful. Check the 'output.csv' file.")
    except Exception as e:
        print(f"Error: {e}")
