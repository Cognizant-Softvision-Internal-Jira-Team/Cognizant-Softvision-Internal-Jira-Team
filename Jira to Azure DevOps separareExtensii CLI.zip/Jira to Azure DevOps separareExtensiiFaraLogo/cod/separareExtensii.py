import tkinter as tk
from tkinter import filedialog, simpledialog
import csv

def process_strings(input_strings, output_file):
    try:
        names = []
        extensions = []

        for string in input_strings:
            if "." in string:
                last_dot_index = string.rfind('.')
                name = string[:last_dot_index]
                extension = string[last_dot_index:]
                names.append(name)
                extensions.append(extension)

        with open(output_file, 'w', newline='', encoding='utf-8') as outfile:
            writer = csv.writer(outfile)
            writer.writerow(['Names', 'Extensions'])
            writer.writerows(zip(names, extensions))

        print(f"CSV file '{output_file}' created successfully.")

    except Exception as e:
        print(f"Error: {e}")

def open_file_dialog():
    file_path = filedialog.askopenfilename(title="Make Your Spreadsheet Great Again!", filetypes=[("CSV Files", "*.csv")])
    return file_path

def save_file_dialog():
    file_path = filedialog.asksaveasfilename(title="Save CSV File", defaultextension=".csv", filetypes=[("CSV Files", "*.csv")])
    return file_path

def main():
    root = tk.Tk()
    root.title("Separarea numelor de extensii")

    # Label above "Select CSV File" button
    label_above_button = tk.Label(root, text="Vei obtine separarea numelor de extensii ale unor fisiere dintr-o lista .csv")
    label_above_button.pack(pady=10)

    # Open File Button
    open_button = tk.Button(root, text="open .csv! Very nice! Great Success!", command=lambda: open_file())
    open_button.pack(pady=10)

    def open_file():
        input_file_path = open_file_dialog()
        if input_file_path:
            output_file_path = save_file_dialog()
            if output_file_path:
                with open(input_file_path, 'r', newline='', encoding='utf-8') as infile:
                    reader = csv.reader(infile)
                    input_strings = [row[0] for row in reader]

                process_strings(input_strings, output_file_path)

    # Details label in the lower right corner
    details_label = tk.Label(root, text="Have no care with ©FilipWare - very nice software, not joke!", font=("Helvetica", 8, "italic"))
    details_label.pack(side=tk.RIGHT, padx=10, pady=10)  # Set side to RIGHT

    # Run the main loop
    root.mainloop()

if __name__ == "__main__":
    main()
